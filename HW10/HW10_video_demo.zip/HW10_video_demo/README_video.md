# HW10 Demo Video

Files:
- HW10_demo_video.mp4: short demo video
- HW10_demo_video.gif: small preview GIF

This video demonstrates the HW10 idea:
- Pico streams `adc,button`
- potentiometer controls the player left/right
- button makes the player jump
- Python game/visualization responds to serial data
